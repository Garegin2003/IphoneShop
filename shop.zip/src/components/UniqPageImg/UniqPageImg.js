import React from "react";

function UniqPageImg(props) {
    return(
        <div className="img">
            <img src={props.img}/>
        </div>
    )
}

export default UniqPageImg