import images1 from './1.jpg' 
import images2 from './2.jpg' 
import images3 from './3.jpg' 
import images4 from './4.jpg' 
import images5 from './5.jpg' 
import images6 from './6.jpg' 
import images7 from './7.jpg' 
import images8 from './8.jpg' 
import images9 from './9.jpg' 


const arr = [images1, images2, images3, images4, images5, images6, images7, images8, images9]

export default arr